<?php
require_once '../php/db_connect.php';
session_start();

// You can pass Member_ID either through session (preferred) or GET param
$memberID = $_SESSION['Member_ID'] ?? $_GET['Member_ID'] ?? null;

if (!$memberID) {
    echo json_encode(["status" => "error", "message" => "Member not logged in"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch profile info
    $stmt = $conn->prepare("SELECT * FROM 2kmicl_regmem WHERE Member_ID = ?");
    $stmt->bind_param("s", $memberID);
    $stmt->execute();
    $profileResult = $stmt->get_result()->fetch_assoc();

    // Fetch loan info
    $stmt2 = $conn->prepare("SELECT * FROM loans WHERE Member_ID = ? ORDER BY Loan_ID DESC LIMIT 1");
    $stmt2->bind_param("s", $memberID);
    $stmt2->execute();
    $loanResult = $stmt2->get_result()->fetch_assoc();

    echo json_encode([
        "status" => "success",
        "profile" => $profileResult,
        "loan" => $loanResult
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Loan application submission
    $loanAmount = $_POST['Loan_Amount'];
    $terms = $_POST['Terms'];
    $interestRate = $_POST['Interest_Rate'];
    $proceedsMode = $_POST['Proceeds_Mode'];
    $netProceeds = $_POST['Net_Proceeds'];
    $amountToRepay = $_POST['Amount_To_Repay'];
    $repaymentDate = $_POST['Repayment_Date'];

    // Generate new loan code depending on eligibility
    $loanCode = $_POST['Loan_Code']; // Already computed in JS based on Loan_Elig

    $stmt = $conn->prepare("INSERT INTO loans 
        (Member_ID, First_Name, Middle_Name, Last_Name, Loan_Code_Applied, Loan_Amount, Terms, Interest_Rate, Proceeds_Mode, Net_Proceeds, Amount_To_Repay, Repayment_Date, Status, Loan_Elig) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Running', 'No')");
    $stmt->bind_param(
        "sssssdsssdss",
        $memberID,
        $_POST['First_Name'],
        $_POST['Middle_Name'],
        $_POST['Last_Name'],
        $loanCode,
        $loanAmount,
        $terms,
        $interestRate,
        $proceedsMode,
        $netProceeds,
        $amountToRepay,
        $repaymentDate
    );
    $stmt->execute();

    echo json_encode([
        "status" => "success",
        "message" => "Loan application submitted successfully"
    ]);
    exit;
}
?>