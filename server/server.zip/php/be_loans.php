<?php
header("Content-Type: application/json");
require_once __DIR__ . "/db_connect.php"; // Adjust path

$action = $_GET['action'] ?? '';

if ($action === 'fetch') {
    $stmt = $pdo->query("SELECT * FROM loans");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

if ($action === 'update') {
    $data = json_decode(file_get_contents("php://input"), true);
    if (!isset($data['Loan_ID'], $data['field'], $data['value'])) {
        echo json_encode(["success" => false, "error" => "Missing parameters"]);
        exit;
    }

    $allowedFields = ['Status', 'Date_Paid', 'Loan_Elig', 'Remarks'];
    if (!in_array($data['field'], $allowedFields)) {
        echo json_encode(["success" => false, "error" => "Invalid field"]);
        exit;
    }

    $sql = "UPDATE loans SET {$data['field']} = :value WHERE Loan_ID = :loan_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ":value" => $data['value'],
        ":loan_id" => $data['Loan_ID']
    ]);

    echo json_encode(["success" => true]);
    exit;
}

echo json_encode(["success" => false, "error" => "Invalid action"]);