<?php
require_once '../php/db_connect.php'; // DB connection

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $firstName = $_POST['First_Name'];
    $middleName = $_POST['Middle_Name'];
    $lastName = $_POST['Last_Name'];
    $birthdate = $_POST['Birthdate'];
    $address = $_POST['Address'];
    $employeeNumber = $_POST['Employee_Number'];
    $station = $_POST['Station'];
    $contactNumber = $_POST['Contact_Number'];
    $validID = $_POST['Valid_ID'];
    $eWalletVendor = $_POST['eWallet_Vendor'];
    $eWalletAccount = $_POST['eWallet_Account'];
    $memberID = $_POST['Member_ID'];
    $pin = $_POST['PIN'];

    // Upload ID front and back
    $uploadDir = '../uploads/';
    $idFrontName = $lastName . '-' . $firstName . '-Front.png';
    $idBackName  = $lastName . '-' . $firstName . '-Back.png';

    move_uploaded_file($_FILES['ID_Front']['tmp_name'], $uploadDir . $idFrontName);
    move_uploaded_file($_FILES['ID_Back']['tmp_name'], $uploadDir . $idBackName);

    // Insert into registration table
    $stmt = $conn->prepare("INSERT INTO 2kmicl_regmem 
        (First_Name, Middle_Name, Last_Name, Birthdate, Address, Employee_Number, Station, Contact_Number, Valid_ID, ID_Front, ID_Back, eWallet_Vendor, eWallet_Account, Member_ID, PIN, Loan_Elig) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Yes-A1')");
    $stmt->bind_param("sssssssssssssss",
        $firstName, $middleName, $lastName, $birthdate, $address, $employeeNumber, $station,
        $contactNumber, $validID, $idFrontName, $idBackName, $eWalletVendor, $eWalletAccount,
        $memberID, $pin
    );
    $stmt->execute();

    // Insert into loans table (prof_loan functionality)
    $stmt2 = $conn->prepare("INSERT INTO loans 
        (Member_ID, First_Name, Middle_Name, Last_Name, Loan_Code_Applied, Status, Loan_Elig) 
        VALUES (?, ?, ?, ?, 'A1', 'Running', 'Yes')");
    $stmt2->bind_param("ssss", $memberID, $firstName, $middleName, $lastName);
    $stmt2->execute();

    echo json_encode([
        "status" => "success",
        "message" => "Registration and loan profile created",
        "Member_ID" => $memberID,
        "PIN" => $pin
    ]);
}
?>