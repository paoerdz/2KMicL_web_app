CREATE TABLE loans (
    Loan_ID INT AUTO_INCREMENT PRIMARY KEY,
    Member_ID INT NOT NULL,
    First_Name VARCHAR(50) NOT NULL,
    Middle_Name VARCHAR(50),
    Last_Name VARCHAR(50) NOT NULL,
    Loan_Code_Applied ENUM('A1','B1','B2','B3') NOT NULL,
    Loan_Code VARCHAR(20) NOT NULL,
    Loan_Amount DECIMAL(10,2) NOT NULL,
    Terms VARCHAR(50) NOT NULL,
    Interest DECIMAL(5,2) NOT NULL,
    Proceeds_Mode VARCHAR(50) NOT NULL,
    Proceeds DECIMAL(10,2) NOT NULL,
    Repayment_Date DATE NOT NULL,
    Repayment_Amount DECIMAL(10,2) NOT NULL,

    -- Newly requested columns
    Status ENUM('Running', 'Due now', 'Overdue', 'Requested payment extension', 'Paid') DEFAULT 'Running',
    Date_Paid DATE DEFAULT NULL,
    Loan_Elig ENUM('Yes', 'No') DEFAULT 'No',
    Remarks TEXT,

    FOREIGN KEY (Member_ID) REFERENCES 2kmicl_regmem(Member_ID) ON DELETE CASCADE
);