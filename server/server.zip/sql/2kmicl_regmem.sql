-- Create database (if not exists)
CREATE DATABASE IF NOT EXISTS `2kmicl_db`;
USE `2kmicl_db`;

-- Drop table if it exists
DROP TABLE IF EXISTS `2kmicl_regmem`;

-- Create table
CREATE TABLE `2kmicl_regmem` (
    `ID` INT(11) NOT NULL AUTO_INCREMENT,
    `First_Name` VARCHAR(100) NOT NULL,
    `Middle_Name` VARCHAR(100) DEFAULT NULL,
    `Last_Name` VARCHAR(100) NOT NULL,
    `Birthdate` DATE NOT NULL,
    `Address` VARCHAR(255) NOT NULL,
    `Employee_Number` VARCHAR(50) NOT NULL,
    `Station` VARCHAR(100) NOT NULL,
    `Contact_Number` VARCHAR(15) NOT NULL,
    `Valid_ID` VARCHAR(50) NOT NULL,
    `ID_Front` VARCHAR(255) NOT NULL, -- filename only, stored in uploads folder
    `ID_Back` VARCHAR(255) NOT NULL,  -- filename only, stored in uploads folder
    `eWallet_Vendor` VARCHAR(50) NOT NULL,
    `eWallet_Account/Number` VARCHAR(50) NOT NULL,
    `Member ID` VARCHAR(20) NOT NULL,
    `PIN` VARCHAR(10) NOT NULL,
    `Loan_Elig` ENUM(
        'Yes-A1', -- Just Signed Up (New Member)
        'Yes-B1', -- Paid A1
        'Yes-B2', -- Paid B1
        'Yes-B3', -- Paid B2
        'No-X1',  -- Profile has issues
        'No-B1',  -- Unpaid A1
        'No-B2',  -- Unpaid B1
        'No-B3'   -- Unpaid B2
    ) NOT NULL DEFAULT 'Yes-A1',
    PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
